exec(open('fast2.py').read())
import itertools
CACHE={}
for p in PAIRS:
    for d in DAYS:
        i=IDX[(p,d)]
        if i is None: continue
        for n in (2,3,5):
          for tol in (0.01,0.015,0.02):
            CACHE[(p,d,n,tol)]=lv(p,i,n=n,tol=tol)
def run(n,tol,minside,maxlast,mint,b,one):
    tp=fp=fn=0
    for p in PAIRS:
        K=PAIRS[p]
        for d in DAYS:
            i=IDX[(p,d)]
            if i is None: continue
            c0,c1=K[i][4],K[i-1][4]; evs=[]
            for l in CACHE[(p,d,n,tol)]:
                L=l['L']
                if l['t']<mint or l['last']>maxlast: continue
                if c0>L*(1+b) and c1<=L*(1+b) and l['nH']>=minside: evs.append((1,L,l['t']))
                if c0<L*(1-b) and c1>=L*(1-b) and l['nL']>=minside: evs.append((2,L,l['t']))
            if one and evs: evs=[max(evs,key=lambda x:x[2])]
            tr=TRUTH.get((p,d),[])
            m=any(any(t==tt and abs(L/LL-1)<0.01 for t,L,_ in evs) for tt,LL in tr)
            if tr and m: tp+=1
            elif tr: fn+=1
            if evs and not m: fp+=1
    r=tp/(tp+fn); pr=tp/(tp+fp) if tp+fp else 0
    return (2*r*pr/(r+pr+1e-9),r,pr,tp,fp,fn)
res=[]
for P in itertools.product((2,3,5),(0.01,0.015,0.02),(1,2,3),(30,60,120,730),(2,3),(0.0,0.01),(False,True)):
    res.append((run(*P),P))
res.sort(key=lambda x:-x[0][0])
for r,P in res[:12]: print('F1 %.2f recall %.2f precision %.2f tp %d fp %d fn %d'%r,'n,tol,minSide,maxLast,minTouch,buf,onePerDay=',P)
