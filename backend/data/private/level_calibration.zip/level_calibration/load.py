import json,csv,datetime,os
rows=[r for r in csv.reader(l for l in open('/mnt/user-data/outputs/larsson_events_1.csv') if not l.startswith('#'))]
h=rows[0]; E=[dict(zip(h,r)) for r in rows[1:]]
def bars(p):
    f=f"k_{p}.json"
    return json.load(open(f)) if os.path.exists(f) else None
def idx(K,date):
    ts=int(datetime.datetime(2026,int(date[:2]),int(date[3:]),tzinfo=datetime.timezone.utc).timestamp()*1000)
    for i,k in enumerate(K):
        if k[0]==ts: return i
    return None
EVENTS=[]
for e in E:
    p=e['sym'].upper()+('USDT' if e['side']=='U' else 'BTC'); K=bars(p)
    if not K: continue
    i=idx(K,e['date'])
    if i is None: continue
    e.update(pair=p,K=K,i=i,level=float(e['level']),pclose=float(e['close']),ev=int(e['ev']))
    EVENTS.append(e)
