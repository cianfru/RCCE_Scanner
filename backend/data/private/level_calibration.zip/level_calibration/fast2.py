exec(open('fast.py').read())
def allpiv2(p,n):
    K=PAIRS[p]; top=np.array([max(x[1],x[4]) for x in K]); bot=np.array([min(x[1],x[4]) for x in K]); P=[]
    for j in range(n,len(K)-n):
        if top[j]==top[j-n:j+n+1].max(): P.append((j,top[j],'H'))
        if bot[j]==bot[j-n:j+n+1].min(): P.append((j,bot[j],'L'))
    return P
PV2={}
def lv(p,i,n=3,tol=0.015,W=730,gap=10):
    if (p,n) not in PV2: PV2[(p,n)]=allpiv2(p,n)
    P=sorted([x for x in PV2[(p,n)] if i-W<=x[0]<i-n],key=lambda x:x[1]); C=[];cur=[]
    for x in P:
        if cur and x[1]>cur[0][1]*(1+tol): C.append(cur); cur=[]
        cur.append(x)
    if cur: C.append(cur)
    out=[]
    for c in C:
        js=sorted(x[0] for x in c); t=[js[0]]
        for j in js[1:]:
            if j-t[-1]>=gap: t.append(j)
        out.append(dict(L=float(np.mean([x[1] for x in c])),t=len(t),nH=sum(1 for x in c if x[2]=='H'),nL=sum(1 for x in c if x[2]=='L'),first=i-js[0],last=i-js[-1],span=js[-1]-js[0]))
    return out
