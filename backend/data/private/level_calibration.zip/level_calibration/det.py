import numpy as np
def pivots(K,i,n=3,W=365,src='body'):
    lo=max(0,i-W); P=[]
    for j in range(lo+n,i-n):
        if src=='body':
            top=[max(K[k][1],K[k][4]) for k in range(j-n,j+n+1)]; bot=[min(K[k][1],K[k][4]) for k in range(j-n,j+n+1)]
        elif src=='close':
            top=bot=[K[k][4] for k in range(j-n,j+n+1)]
        else:
            top=[K[k][2] for k in range(j-n,j+n+1)]; bot=[K[k][3] for k in range(j-n,j+n+1)]
        if top[n]==max(top): P.append((j,top[n],'H'))
        if bot[n]==min(bot): P.append((j,bot[n],'L'))
    return P
def clusters(P,tol=0.02,minn=2):
    ps=sorted(P,key=lambda x:x[1]); C=[]; cur=[]
    for p in ps:
        if cur and p[1]>cur[0][1]*(1+tol): 
            if len(cur)>=minn: C.append(cur)
            cur=[]
        cur.append(p)
    if len(cur)>=minn: C.append(cur)
    return C
