exec(open('fast2.py').read())
import statistics as st
TP=[];FP=[]
for p in PAIRS:
    K=PAIRS[p]
    for d in DAYS:
        i=IDX[(p,d)]
        if i is None: continue
        tr=TRUTH.get((p,d),[]); c0,c1=K[i][4],K[i-1][4]
        for l in lv(p,i):
            L=l['L']
            if l['t']<2: continue
            t=1 if (c0>L*1.01 and c1<=L*1.01) else 2 if (c0<L*0.99 and c1>=L*0.99) else 0
            if not t: continue
            (TP if any(tt==t and abs(L/LL-1)<0.01 for tt,LL in tr) else FP).append(l)
for name,S in (('TP',TP),('FP',FP)):
    q=lambda k:[round(x,1) for x in st.quantiles([s[k] for s in S],n=4)]
    print(name,len(S),'t',q('t'),'nH',q('nH'),'nL',q('nL'),'first',q('first'),'last',q('last'),'span',q('span'),'both-sides %.2f'%(sum(1 for s in S if s['nH']>0 and s['nL']>0)/len(S)))
