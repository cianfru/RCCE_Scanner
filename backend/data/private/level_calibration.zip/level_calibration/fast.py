exec(open('load.py').read())
import numpy as np
good=[e for e in EVENTS if abs(e['K'][e['i']][4]/e['pclose']-1)<0.01]
DAYS=['09-17','09-18','09-19','09-20','09-21','09-22','09-23','09-24']
PAIRS={e['pair']:e['K'] for e in good}
TRUTH={}
for e in good:
    if e['ev'] in (1,2): TRUTH.setdefault((e['pair'],e['date']),[]).append((e['ev'],e['level']))
PIV={}
def allpiv(p,n):
    k=(p,n)
    if k in PIV: return PIV[k]
    K=PAIRS[p]; top=np.array([max(x[1],x[4]) for x in K]); bot=np.array([min(x[1],x[4]) for x in K]); P=[]
    for j in range(n,len(K)-n):
        if top[j]==top[j-n:j+n+1].max(): P.append((j,top[j]))
        if bot[j]==bot[j-n:j+n+1].min(): P.append((j,bot[j]))
    PIV[k]=P; return P
def levels(p,i,n,tol,minn,W,span,gap):
    P=[x for x in allpiv(p,n) if i-W<=x[0]<i-n]
    P.sort(key=lambda x:x[1]); C=[]; cur=[]
    for x in P:
        if cur and x[1]>cur[0][1]*(1+tol): C.append(cur); cur=[]
        cur.append(x)
    if cur: C.append(cur)
    out=[]
    for c in C:
        js=sorted(x[0] for x in c); t=[js[0]]
        for j in js[1:]:
            if j-t[-1]>=gap: t.append(j)
        if len(t)>=minn and t[-1]-t[0]>=span: out.append((float(np.mean([x[1] for x in c])),len(t)))
    return out
def ev(p,i,P):
    n,tol,minn,W,span,gap,b=P; K=PAIRS[p]; c0,c1=K[i][4],K[i-1][4]; out=[]
    for L,t in levels(p,i,n,tol,minn,W,span,gap):
        if c0>L*(1+b) and c1<=L*(1+b): out.append((1,L,t))
        if c0<L*(1-b) and c1>=L*(1-b): out.append((2,L,t))
    return out
IDX={(p,d):idx(K,d) for p,K in PAIRS.items() for d in DAYS}
def score(P):
    tp=fp=fn=0
    for p in PAIRS:
        for d in DAYS:
            i=IDX[(p,d)]
            if i is None: continue
            e=ev(p,i,P); tr=TRUTH.get((p,d),[])
            m=any(any(t==tt and abs(L/LL-1)<0.01 for t,L,_ in e) for tt,LL in tr)
            if tr and m: tp+=1
            elif tr: fn+=1
            if e and not tr: fp+=1
    r=tp/(tp+fn); pr=tp/(tp+fp) if tp+fp else 0
    return r,pr,2*r*pr/(r+pr+1e-9),tp,fp,fn
